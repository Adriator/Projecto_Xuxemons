@extends('layouts.app')

@section('content')
    <h1>Crear usuario</h1>

    <form method="POST" action="{{ route('users.store') }}">
        @csrf
<!--
        <label for="name">Nombre:</label>
        <input type="text" name="name" required>
-->
        <label for="email">Correo electrónico:</label>
        <input type="email" name="email" required>

        <label for="password">Contraseña:</label>
        <input type="password" name="password" required>

        <label for="password_confirmation">Confirmar contraseña:</label>
        <input type="password" name="password_confirmation" required>

        <label for="rol">Rol:</label>
        <select name="rol" required>
            <option value="Admin">Admin</option>
            <option value="Usuario">Usuario</option>
        </select>

        <button type="submit">Guardar</button>
    </form>
@endsection