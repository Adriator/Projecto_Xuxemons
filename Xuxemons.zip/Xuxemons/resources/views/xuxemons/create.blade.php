@extends('layouts.app')

@section('content')
    <h1>Agregar Xuxemon</h1>

    <form action="{{ route('xuxemons.store') }}" method="post">
        @csrf
<!--     <label for="idUsuario">id.Usuario:</label>
         <input type="text" name="idUsuario" step="0.01"> -->

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" required>
            <option value="Agua">Agua</option>
            <option value="Tierra">Tierra</option>
            <option value="Aire">Aire</option>
        </select>

        <label for="img">Imagen:</label>
        <input type="image" name="img" required>
        
        <button type="submit">Guardar Xuxemon</button>
    </form>
@endsection