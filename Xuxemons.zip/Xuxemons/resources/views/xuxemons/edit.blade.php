@extends('layouts.app')

@section('content')
    <h1>Editar Xuxemon</h1>

    <form action="{{ route('xuxemons.update', $xuxemon->id) }}" method="post">
        @csrf
        @method('PUT')

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" value="{{ $xuxemon->nombre }}" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" required>
            <option value="Agua" {{ $xuxemon->tipo === 'Agua' ? 'selected' : '' }}>Agua</option>
            <option value="Tierra" {{ $xuxemon->tipo === 'Tierra' ? 'selected' : '' }}>Tierra</option>
            <option value="Aire" {{ $xuxemon->tipo === 'Aire' ? 'selected' : '' }}>Aire</option>
        </select>

        <label for="img">Imagen:</label>
        <input type="image" name="img" value="{{ $xuxemon->img }}" required>

        <button type="submit">Actualizar Xuxemon</button>
    </form>
@endsection
