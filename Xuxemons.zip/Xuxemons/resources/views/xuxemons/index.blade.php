@extends('layouts.app')

@section('content')
    <h1>Xuxedex</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Tipo</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach($xuxemons as $xuxemon)
                <tr>
                    <td>{{ $xuxemon->id }}</td>
                    <td>{{ $xuxemon->nombre }}</td>
                    <td>{{ $xuxemon->tipo }}</td>
                    <td>{{ $xuxemon->img }}</td>
                    <td>
                        <a href="{{ route('xuxemons.edit', $xuxemon->id) }}">Editar</a>
                        <form action="{{ route('xuxemons.destroy', $xuxemon->id) }}" method="post">
                            @csrf
                            @method('DELETE')
                            <button type="submit">Eliminar</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <a href="{{ route('xuxemons.create') }}">Añadir</a>
@endsection
