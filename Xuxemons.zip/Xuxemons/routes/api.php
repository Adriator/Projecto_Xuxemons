<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\XuxemonController;
use App\Http\Controllers\controladorUsuarios;
use App\Http\Controllers\InventarioController;
use App\Http\Controllers\controladorAmigos;

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware('cors')->group(function () {
    
    //XUXEMONS
    // Crear xuxemon
    Route::post('xuxemons', [XuxemonController::class, 'store'])->name('xuxemons.store');
    // Mostrar todos los xuxemons
    Route::get('xuxemons', [XuxemonController::class, 'index'])->name('xuxemons.index');
    // Mostrar un xuxemon
    Route::get('xuxemons/{id}', [XuxemonController::class, 'show'])->name('xuxemons.show');
    // Actualizar xuxemon
    Route::put('xuxemons/{id}', [XuxemonController::class, 'update'])->name('xuxemons.update');
    // Borrar xuxemon
    Route::delete('xuxemons/{id}', [XuxemonController::class, 'destroy'])->name('xuxemons.destroy');
    // Subir de nivel el xuxemon
    Route::put('xuxemons/{idXuxemon}/darXuxe/{idChuche}', [XuxemonController::class, 'darXuxe'])->name('xuxemons.darXuxe');
    // Recoger los xuxemons enfermos
    Route::get('xuxemons/hospital/hospitalizados', [XuxemonController::class, 'hospital']);
    // Cambiar estado de activo
    Route::put('xuxemons/activarXuxemon/{idXuxemon}', [XuxemonController::class, 'activarXuxemon'])->name('xuxemons.activarXuxemon');


    //CONTROLADOR USUARIOS
    // Registrar usuario
    Route::post('users', [controladorUsuarios::class, 'store'])->name('users.store');
    // Iniciar usuario
    Route::post('login', [controladorUsuarios::class, 'login'])->name('users.login');
    // Mostrar todos los usuarios 
    Route::get('users', [controladorUsuarios::class, 'index'])->name('users.index');
    // Mostrar un usuario
    Route::get('users/{id}', [controladorUsuarios::class, 'show'])->name('users.show');
    // Coger rol usuario
    Route::get('/coger-rol',[controladorUsuarios::class, 'cogerRol'])->name('cogerRol');
    // Actualizar usuario
    Route::put('users/{id}', [controladorUsuarios::class, 'update'])->name('users.update');
    // Borrar usuario 
    Route::delete('users/{id}', [controladorUsuarios::class, 'destroy'])->name('users.destroy');
    //Coger Ajustes
    Route::get('users/ajustes/cogerAjustes', [controladorUsuarios::class, 'cogerAjustes']);
    //Modifica Ajustes
    Route::put('users/ajustes/modificarAjustes', [controladorUsuarios::class, 'modificarAjustes']);
    // Cerrar sesión de usuario 
    Route::post('logout', [controladorUsuarios::class, 'logout'])->name('users.logout');


    //INVENTARIO
    // Mostrar Monedas
    Route::get('monedas', [controladorUsuarios::class, 'totalMonedas']);
    // Crear un objeto/xuxe
    Route::post('inventario', [InventarioController::class, 'store'])->name('inventario.store');
    // Mostrar un objeto/xuxe
    Route::get('inventario/{id}', [InventarioController::class, 'show'])->name('inventario.show');
    // Mostrar objetos/xuxes
    Route::get('inventario/{id}', [InventarioController::class, 'index'])->name('inventario.index');
    // Actualizar un  objeto/xuxe
    Route::put('inventario/{id}', [InventarioController::class, 'update'])->name('inventario.update');
    // Borrar un objeto/xuxe
    Route::delete('inventario/{id}', [InventarioController::class, 'destroy'])->name('inventario.destroy');
    // Cofre de xuxes
    Route::post('inventario/cofreInventarios', [InventarioController::class, 'cofreInventarios']);
    
    //AMIGOS
    // Coger el "discord_tag"
    Route::get('obtener-tag', [controladorUsuarios::class, 'obtenerTag']);
    // Ruta para buscar amigos
    Route::get('email/{discord_tag}', [controladorAmigos::class, 'obtenerEmail']);
    // Ruta para añadir un amigo
    Route::post('/amigos/anadir', [ControladorAmigos::class, 'anadirAmigo'])->name('amigos.anadir');  
    // Ruta para mostrar la lista de amigos
    Route::get('/amigos/mostrar', [controladorAmigos::class, 'mostrarAmigos'])->name('amigos.mostrar');  //Hecho
    // Ruta para mostrar las solicitudes de amistad
    Route::get('/amigos/solicitud', [controladorAmigos::class, 'mostrarSolicitudes'])->name('amigos.solicitud'); //Hecho
    // Ruta para aceptar una solicitud de amistad
    Route::post('/amigos/aceptar/{idSolicitud}', [controladorAmigos::class, 'aceptarAmigo'])->name('amigos.aceptar');
    // Ruta para rechazar una solicitud de amistad
    Route::post('/amigos/rechazar/{idSolicitud}', [controladorAmigos::class, 'rechazarSolicitudAmistad'])->name('amigos.rechazar');
});