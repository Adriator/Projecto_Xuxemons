<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\XuxemonController;
use App\Http\Controllers\controladorUsuarios;
use App\Http\Controllers\InventarioController;

Route::middleware('cors')->group(function () {
    Route::resource('xuxemons', XuxemonController::class);
    Route::resource('users', controladorUsuarios::class);
    Route::resource('inventario', InventarioController::class);
    Route::post('/login', [controladorUsuarios::class, 'login']);
    Route::post('/logout', [controladorUsuarios::class, 'logout']);
    Route::put('xuxemons/{idXuxemon}/darXuxe/{idChuche}', [XuxemonController::class, 'darXuxe'])->name('xuxemons.darXuxe');
    // Coger rol usuario
    Route::get('/coger-rol',[controladorUsuarios::class, 'cogerRol'])->name('cogerRol');
    // Mostrar Monedas
    Route::get('users/{id}/monedas', [controladorUsuarios::class, 'totalMonedas']);
});    