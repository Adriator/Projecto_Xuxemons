<?php

namespace Database\Seeders;

use App\Models\Inventario;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class InventarioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $inventario = [
            [
                'nombre' => 'Dulces',
                'tipo' => 'Xuxes',
                'cantidad' => '5',
                'descripcion' => 'Comida que proporciona experiencia',
                'img' => 'assets/extras/dulces.png',
            ],
            [
                'nombre' => 'Pala',
                'tipo' => 'Xuxes',
                'cantidad' => '1',
                'descripcion' => 'Objeto que se come agusto',
                'img' => 'assets/extras/pala.png',
            ],
            [
                'nombre' => 'Xal de frutas',
                'tipo' => 'Objeto',
                'cantidad' => '1',
                'descripcion' => 'Cura la enfermedad “Atracón”',
                'img' => 'assets/extras/frutas.png',
            ],
            [
                'nombre' => 'Xocolatina',
                'tipo' => 'Objeto',
                'cantidad' => '3',
                'descripcion' => 'Cura la enfermedad “Bajón de azúcar”',
                'img' => 'assets/extras/chocolate.png',
            ],
            [
                'nombre' => 'Inxulina',
                'tipo' => 'Objeto',
                'cantidad' => '2',
                'descripcion' => 'Cura la enfermedad “Sobredosis de azúcar”',
                'img' => 'assets/extras/inxulina.png',
            ],
        ];
        // Insert the data into the database
        foreach ($inventario as $data) {
            Inventario::create($data);
        }
    }
}