<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeed extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = [
            [
                'email' => 'admin@gmail.com',
                'password' => '123456789',
                'rol' => 'Admin',
                'discord_tag'=>'1111',
            ],
            [
                'email' => 'usuario@gmail.com',
                'password' => '123456789',
                'rol' => 'Usuario',
                'discord_tag'=>'2222',
            ],
        ];

        // Insert the data into the database
        foreach ($users as $data) {
            User::create($data);
        }
    }
}