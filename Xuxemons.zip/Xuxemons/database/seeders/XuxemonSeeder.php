<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Xuxemon;

class XuxemonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Datos de los xuxemons
        $xuxemonData = [
            [ 'nombre' => 'Apleki', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/apleki.png', ],
            [ 'nombre' => 'Avecrem', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/avecrem.png', ],
            [ 'nombre' => 'Bambino', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/bambino.png', ],
            [ 'nombre' => 'Beeboo', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/beeboo.png', ],
            [ 'nombre' => 'Boo-hoot', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/boo-hoot.png', ],
            [ 'nombre' => 'Cabrales', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/cabrales.png', ],
            [ 'nombre' => 'Catua', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/catua.png', ],
            [ 'nombre' => 'Catyuska', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/catyuska.png', ],
            [ 'nombre' => 'Chapapá', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/chapapa.png', ],
            [ 'nombre' => 'Chopper', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/chopper.png', ],
            [ 'nombre' => 'Cuellilargui', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/cuellilargui.png', ],
            [ 'nombre' => 'Deskangoo', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/deskangoo.png', ],
            [ 'nombre' => 'Dolly', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/dolly.png', ],
            [ 'nombre' => 'Elconchudo', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/elconchudo.png', ],
            [ 'nombre' => 'Eldientes', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/eldientes.png', ],
            [ 'nombre' => 'Elgominas', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/elgominas.png', ],
            [ 'nombre' => 'Flipper', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/flipper.png', ],
            [ 'nombre' => 'Floppi', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/floppi.png', ],
            [ 'nombre' => 'Horseluis', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/horseluis.png', ],
            [ 'nombre' => 'Krokolisko', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/krokolisko.png', ],
            [ 'nombre' => 'Kurama', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/kurama.png', ],
            [ 'nombre' => 'Ladybug', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/ladybug.png', ],
            [ 'nombre' => 'Lengualargui', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/lengualargui.png', ],
            [ 'nombre' => 'Medusation', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/medusation.png', ],
            [ 'nombre' => 'Meekmeek', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/meekmeek.png', ],
            [ 'nombre' => 'Megalo', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/megalo.png', ],
            [ 'nombre' => 'Mocha', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/mocha.png', ],
            [ 'nombre' => 'Murcimurci', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/murcimurci.png', ],
            [ 'nombre' => 'Nemo', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/nemo.png', ],
            [ 'nombre' => 'Oinkcelot', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/oinkcelot.png', ],
            [ 'nombre' => 'Oreo', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/oreo.png', ],
            [ 'nombre' => 'Otto', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/otto.png', ],
            [ 'nombre' => 'Pinchimott', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/pinchimott.png', ],
            [ 'nombre' => 'Pollis', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/pollis.png', ],
            [ 'nombre' => 'Posón', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/poson.png', ],
            [ 'nombre' => 'Quakko', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/quakko.png', ],
            [ 'nombre' => 'Rajoy', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/rajoy.png', ],
            [ 'nombre' => 'Rawlion', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/rawlion.png', ],
            [ 'nombre' => 'Rexxo', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/rexxo.png', ],
            [ 'nombre' => 'Ron', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/ron.png', ],
            [ 'nombre' => 'Sesssi', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/sesssi.png', ],
            [ 'nombre' => 'Shelly', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/shelly.png', ],
            [ 'nombre' => 'Sirucco', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/sirucco.png', ],
            [ 'nombre' => 'Torcas', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/torcas.png', ],
            [ 'nombre' => 'Trompeta', 'tipo' => 'Aire','tamano'=> 'Pequeño','img' => 'assets/trompeta.png', ],
            [ 'nombre' => 'Trompi', 'tipo' => 'Tierra','tamano'=> 'Pequeño','img' => 'assets/trompi.png', ],
            [ 'nombre' => 'Tux', 'tipo' => 'Agua','tamano'=> 'Pequeño','img' => 'assets/tux.png', ]
        ];
        
        foreach ($xuxemonData as $data) {
        Xuxemon::create($data);
        }
    }
}
