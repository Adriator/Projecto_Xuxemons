<?php

namespace Database\Seeders;

use App\Models\Enfermedades;
use Illuminate\Database\Seeder;

class EnfermedadSeeder extends Seeder
{
  public function run(): void{
    $enfermedades = [
    ['nombre' => 'Bajón de azúcar','descripcion' => 'Requiere +2 xuxes por nivel para crecer','cura' => 'Xocolatina',],
    ['nombre' => 'Sobredosis de azúcar','descripcion' => 'Si el xuxemon está en activo no se puede usar para nada','cura' => 'Inxulina',],
    ['nombre' => 'Atracón','descripcion' => 'El xuxemon no puede alimentarse, por tanto el usuario no puede darle de comer','cura' => 'Xal de frutas',],];
    foreach ($enfermedades as $data) {
        Enfermedades::create($data);
    }}
}