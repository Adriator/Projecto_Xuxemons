<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Ajustes;

class AjustesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $ajustes = [
            [
                'parametro' => 'amediano',
                'valor' => '3',
            ],
            [
                'parametro' => 'agrande',
                'valor' => '8',
            ],
            [
                'parametro' => 'tamanodefecto',
                'valor' => 'Pequeño',
            ],
            [
                'parametro' => 'xuxesdiarias',
                'valor' => '10',
            ],
        ];
        // Insert the data into the database
        foreach ($ajustes as $data) {
            Ajustes::create($data);
        }
    }
}