<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('xuxemon', function (Blueprint $table) {
            $table->id()->autoIncrement();
            $table->string('nombre');
            $table->enum('tipo', ['Tierra', 'Aire', 'Agua']);
            $table->enum('tamano', ['Pequeño', 'Mediano', 'Grande'])->default('Pequeño');;
            $table->string('img');
            $table->integer('nivel')->default(0);
            $table->boolean('activo')->default(false);
            $table->boolean('bajon_azucar')->default(false);
            $table->boolean('sobredosis_azucar')->default(false);
            $table->boolean('atracon')->default(false);
//            $table->unsignedBigInteger('idUsuario');
//            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('xuxemon');
    }
};
