<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Ajustes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;

class controladorUsuarios extends Controller
{
    public function index()
    {
        $users = User::all();
        return view('users.index', compact('users'));
    }

    public function create()
    {
        return view('users.create');
    }

    public function store(Request $request)
    {
        // Validar los datos del formulario
        try{
            $request->validate([
                'email' => 'required|email',
                'password' => 'required|string|min:8',
                'rol' => 'required|in:Admin,Usuario',
            ]);

            $request['discord_tag'] = '';
            for ($i = 0; $i < 4; $i++){
                $request['discord_tag'] .= strval(rand(0,9));
            }

            // Crear un nuevo usuario
            User::create([
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'rol' => $request->rol,
                'discord_tag' => $request->discord_tag,
            ]);
            return response()->json(['message' => 'Usuario creado correctamente'], 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Usuario no insertado'], 404);
        }
    }

    public function show(User $user)
    {
        return view('users.show', compact('user'));
    }

    public function edit(User $user)
    {
        return view('users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        // Validar los datos del formulario
        $request->validate([
            'email' => 'required|email|unique:users,email,'.$user->id,
            // Validar la contraseña solo si se proporciona una nueva
            'password' => $request->password ? 'required|string|min:8' : '',
        ]);

        // Actualizar los datos del usuario
        $user->update([
            'email' => $request->email,
            'password' => $request->password ? bcrypt($request->password) : $user->password,
        ]);

        // Redirigir a la página de detalles del usuario con un mensaje
        return redirect()->route('users.show', $user->id)->with('success', 'Usuario actualizado exitosamente.');
    }

    public function destroy(User $user)
    {
        // Eliminar el usuario
        $user->delete();

        // Redirigir a la página de listado de usuarios con un mensaje
        return redirect()->route('users.index')->with('success', 'Usuario eliminado exitosamente.');
    }

    /*
     * Login de los usuarios
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
    */
    public function login(Request $request) {

        try {
            // Valida los datos
            $validados = $request->validate([
                'email' => 'required|email',
                'password' => 'required|string|min:8',
            ]);
            // Hace el intento de iniciar sesión
            if (Auth::attempt($validados)) {

                // Si las credenciales son correctas
                $user = Auth::user();
                $token = $user->createToken('authToken')->plainTextToken;
                $role = Auth::user()->rol;

                // Devuelve el token de acceso y el tipo de token
                return response()->json([
                    'access_token' => $token,
                    'token_type' => 'bearer',
                    'rol' => $role,
                ], 200);
            } else {
                // Si no, deuvelve credenciales incorrectas
                return response()->json(['message' => 'Credenciales incorrectas'], 401);
            }

        } catch (\Exception $e) {
            // Si existe algun error, se muestras
            return response()->json(['message' => 'Ha ocurrido un error al hacer login: ' . $e->getMessage()], 500);
        }
    }


        /**
     * Cerrar sesión del usuario
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout() {

        try {
            // Busca el usuario
            $user = Auth::guard('sanctum')->user();

            if ($user) {
                // Y elimina el token de acceso del usuario
                $user->currentAccessToken()->delete();
               
                // Devuelve un OK
                return response()->json(['message' => 'Se ha cerrado la sesión de forma satisfactoria'], 200);
            } else {
                // Si no se ha podido encontrar el usuario
                return response()->json(['message' => 'User not found'], 404);
            }

        } catch (\Exception $e) {
            // Si hay algun error se muestra
            return response()->json(['message' => 'Ha ocurrido un error al hacer logout: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Coger el rol del usuario
     * @return userRole
     */

    public function cogerRol(){

        try {
            /*Comprueba que el usuario existe */
            if (!empty(Auth::guard('sanctum')->user())) {
                $user = Auth::guard('sanctum')->user();
                if ($user){
                    /*Si el usuario existe devuelve el rol del usuario*/
                    return response()->json(['rol' => $user->rol], 200);
                } else {
                    return response()->json(['message' => 'Usuario no encontrado'],404);
                }
            } else {
                return response()->json(['message' => 'Usuario no encontrado'],404);
            }
        } catch (\Exception $e) {
            // Si hay algún error se muestra
            return response()->json(['message' => 'Ha habido un error' . $e->getMessage()], 500);
        }
    }

    /**
     * Coger la cantidad de monedas del usuario
     * @return userRole
     */

    public function totalMonedas()
    {
        try {
            $user = Auth::guard('sanctum')->user();
            return($user->monedas);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener el discord_tag: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Coger datos tabla Ajustes
     * @return Ajustes
     */

     public function cogerAjustes()
     {
         try {
             $amediano = Ajustes::where('parametro', 'amediano')->first();
             $agrande = Ajustes::where('parametro', 'agrande')->first();
             $tamanodefecto = Ajustes::where('parametro', 'tamanodefecto')->first();
             $xuxesdiarias = Ajustes::where('parametro', 'xuxesdiarias')->first();
     
             return response()->json([$tamanodefecto->valor, $amediano->valor, $agrande->valor,$xuxesdiarias->valor], 200);
         } catch (\Exception $e) {
             return response()->json(['message' => 'Ha habido un error' . $e->getMessage()], 500);
         }
     }
     

    /**
     * Modifica datos tabla Ajustes
     * @return Ajustes
     */

     public function modificarAjustes(Request $request)
     {
        try {
            // Obtener los datos enviados en la solicitud
            $tamanoDefecto = $request->input('tamanoDefecto');
            $caramelosNecesariosMediano = $request->input('caramelosNecesariosMediano');
            $caramelosNecesariosGrande = $request->input('caramelosNecesariosGrande');
            $xuxesdiarias = $request->input('xuxesdiarias');
            
            // Actualizar los ajustes en la base de datos
            Ajustes::where('parametro', 'tamanodefecto')->update(['valor' => $tamanoDefecto]);
            Ajustes::where('parametro', 'amediano')->update(['valor' => $caramelosNecesariosMediano]);
            Ajustes::where('parametro', 'agrande')->update(['valor' => $caramelosNecesariosGrande]);
            Ajustes::where('parametro', 'xuxesdiarias')->update(['valor' => $xuxesdiarias]);

            // Devolver una respuesta de éxito
            return response()->json(['message' => 'Ajustes actualizados correctamente'], 200);
        } catch (\Exception $e) {
            // Si hay algún error, devolver una respuesta de error
            return response()->json(['message' => 'Ha habido un error' . $e->getMessage()], 500);
        }
    }

    // Función para obtener el discor_tag
    public function obtenerTag()
    {
        try {
            $user = Auth::guard('sanctum')->user();
            return($user->discord_tag);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener el discord_tag: ' . $e->getMessage()], 500);
        }
    }
}