<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Exception;
use App\Models\Amigos;

class controladorAmigos extends Controller
{
    /**
     * Busca amigos para enviar solicitud
     */
    public function obtenerEmail(Request $request, $discord_tag)
    {
        $user = User::where('discord_tag', $discord_tag)->first();

        if ($user) {
            return response()->json(['email' => $user->email], 200);
        } else {
            return response()->json(['error' => 'Usuario no encontrado'], 404);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Envia solicitud de amistad al usuario
     */
    public function anadirAmigo(Request $request)
    {
        try {
            // Valida los datos
            $request->validate([
                'email' => ['required', 'email', 'exists:users'],
            ]);
   
            // Obtener el usuario correspondiente al email
            $usuario = User::where('email', $request->email)->first();
   
            // Comprobar si se encontró un usuario
            if (!$usuario) {
                return response()->json(['message' => 'No se encontró ningún usuario con este email'], 404);
            }
   
            // Obtener el ID del usuario
            $idUsuario = $usuario->id;
   
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario autenticado
                $usuarioAutenticado = Auth::guard('sanctum')->user();
            }
   
            // Comprueba si ya son amigos
            if ($usuarioAutenticado->sonAmigos->contains($idUsuario) ||
                $usuarioAutenticado->sonAmigos_r->contains($idUsuario)) {
                return response()->json(['message' => 'Ya son amigos'], 400);
            }
   
            // Verifica si ya se ha enviado una petición anteriormente
            if ($usuarioAutenticado->solicitudPendiente->contains($idUsuario)) {
                return response()->json(['message' => 'Ya has enviado una solicitud de amistad'], 400);
            }
   
            // Verifica si el usuario autenticado está intentando agregarse a sí mismo
            if ($idUsuario == $usuarioAutenticado->id) {
                return response()->json(['message' => 'No te puedes añadir como amigo'], 400);
            }
   
            // Envia la solicitud de amistad
            DB::transaction(function () use ($usuarioAutenticado, $idUsuario) {
                $usuarioAutenticado->amigos()->attach($idUsuario);
            });
   
            // Devuelve un mensaje de respuesta
            return response()->json(['message' => 'Solicitud enviada correctamente'], 200);
        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra la lista de amigos que tiene el usuario
     */
    public function mostrarAmigos()
    {
        try {
            // Obtener usuario autenticado
            $user = Auth::guard('sanctum')->user();
            $userId = $user->id;
            $userEmail = $user->email;
    
            // Obtener registros de la tabla 'amigos' para el usuario autenticado
            $amigos = Amigos::where(function($query) use ($userId) {
                                $query->where('idEnviado', $userId)
                                      ->orWhere('idRecibido', $userId);
                             })
                             ->where('esAmigo', true)
                             ->select('idEnviado', 'idRecibido')
                             ->get();
    
            // Obtener los correos electrónicos de los usuarios
            $correos = [];
            foreach ($amigos as $amigo) {
                $amigosEmails = User::whereIn('id', [$amigo->idEnviado, $amigo->idRecibido])
                                    ->where('email', '!=', $userEmail)
                                    ->pluck('email');
                // Agregar correos electrónicos diferentes al userEmail
                $correos = array_merge($correos, $amigosEmails->toArray());
            }
            // Retornar los correos electrónicos únicos
            return array_unique($correos);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener los correos electrónicos de los amigos: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra las solicitudes entrantes del usuario
     */
    public function mostrarSolicitudes()
{
    try {
        // Obtener usuario autenticado
        $user = Auth::guard('sanctum')->user();
        $userId = $user->id;
        $userEmail = $user->email;

        // Obtener registros de la tabla 'amigos' donde idRecibido sea el userId y esAmigo sea false
        $noAmigos = Amigos::where('idRecibido', $userId)
                          ->where('esAmigo', false)
                          ->select('id', 'idEnviado', 'idRecibido') // Seleccionamos también la ID
                          ->get();

        // Obtener los correos electrónicos de los usuarios que no son amigos
        $solicitudes = [];
        foreach ($noAmigos as $noAmigo) {
            $amigoId = $noAmigo->idEnviado != $userId ? $noAmigo->idEnviado : $noAmigo->idRecibido;
            $amigoEmail = User::where('id', $amigoId)->pluck('email')->first();
            $solicitudes[] = [
                'id' => $noAmigo->id, // Agregamos la ID del registro
                'email' => $amigoEmail
            ];
        }

        // Retornar los correos electrónicos de usuarios que no son amigos junto con sus IDs
        return array_unique($solicitudes);
    } catch (\Exception $e) {
        return response()->json(['message' => 'Ha ocurrido un error al obtener las solicitudes de amistad: ' . $e->getMessage()], 500);
    }
}


    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Acepta la solictud de amistad
     */
    public function aceptarAmigo(Request $request,$idSolicitud)
    {
        try {
        // Primero, encontramos el registro por su ID
        $registro = Amigos::findOrFail($idSolicitud);

        // Cambiamos el campo de false a true
        $registro->esAmigo = true;

        // Guardamos los cambios en la base de datos
        $registro->save();

        // Devuelve un mensaje de confirmación
        return response()->json(['message' => 'Solicitud de amistad aceptada!'], 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Rechaza la solicitud de amistad
     */
    public function rechazarSolicitudAmistad(Request $request,$idSolicitud) {
        try {
        // Encontrar el registro por su ID
        $registro = Amigos::findOrFail($idSolicitud);

        // Eliminar el registro
        $registro->delete();

        // Devuelve un mensaje de confirmación
        return response()->json(['message' => 'Solicitud de amistad rechazada'], 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

}