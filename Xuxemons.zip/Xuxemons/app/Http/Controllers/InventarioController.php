<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Models\Inventario;
use App\Http\Controllers\controladorUsuarios;

class InventarioController extends Controller
{
    // Página principal
    public function index()
    {
        $inventario = Inventario::all();
        return response()->json($inventario, 200);
    }

    public function show($id)
    {
        try {
            $inventario = Inventario::findOrFail($id);
            return response()->json($inventario, 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Inventario no encontrado'], 404);
        }
    }

    // Crear xuxemon
    public function create()
    {
        return view('inventario.create');
    }

    // Guardar datos
    public function store(Request $request)
    {
        try {
            $request->validate([
                'nombre' => 'required|string',
                'tipo' => 'required|in:Objeto,Xuxes',
                'cantidad' => 'required|integer',
                'descripcion' => 'required|string',
                'img' => 'required|string',
            ]);

            Inventario::create($request->all());

            return response()->json(['message' => 'Inventario creado correctamente'], 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Inventario no insertado'], 500);
        }
    }

    public function edit(Inventario $inventario)
    {
        return view('inventario.edit', compact('inventario'));
    }

    public function update(Request $request, $id)
    {
        try {
            $datos = $request->validate([
                'nombre' => 'required|string',
                'tipo' => 'required|in:Objeto,Xuxes',
                'cantidad' => 'required|integer',
                'descripcion' => 'required|string',
                'img' => 'required|string',
            ]);

            $inventario = Inventario::findOrFail($id);
            $inventario->update($datos);

            return response()->json(['inventario' => $inventario, 'message' => 'Inventario actualizado correctamente'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Inventario no actualizado'], 404);
        }
    }

    public function destroy($id)
    {
        $inventario = Inventario::findOrFail($id);
        $inventario->delete();

        return response()->json(['message' => 'Inventario eliminado correctamente'], 200);
    }

    public function cofreInventarios(){

        // Obtener los ajustes
        $ajustesController = new controladorUsuarios();
        $ajustesResponse = $ajustesController->cogerAjustes();
        if ($ajustesResponse->getStatusCode() === 200) {
            $ajustes = json_decode($ajustesResponse->getContent());
            $xuxesdiarias = $ajustes[3];
        } else {
            // Manejar el error si no se pueden obtener los ajustes
            return $ajustesResponse;
        }
        try {
            for ($i = 0; $i < $xuxesdiarias; $i++) {
                // Obtener una ID aleatoria de la tabla donde tipo sea 'Xuxe'
                $inventario = Inventario::where('tipo', 'Xuxes')->inRandomOrder()->first();
                
                // Incrementar la cantidad en 1 para la fila correspondiente a la ID aleatoria
                $inventario->increment('cantidad');
            }
        
            return response()->json(['message' => 'Xuxes añadidas correctamente'], 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Inventario no actualizado: ' . $e->getMessage()], 404);
        }
    }
}