<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Models\Xuxemon;
use App\Models\Inventario;
use App\Http\Controllers\controladorUsuarios;


class XuxemonController extends Controller
{
    // Página principal
    public function index()
    {
        $xuxemons = Xuxemon::all();

        return response()->json($xuxemons, 200);
    }

    public function show($id)
    {
        try {
            $xuxemon = Xuxemon::findOrFail($id);

            return response()->json($xuxemon, 200);
        } catch (ModelNotFoundException $e) {

            return response()->json(['error' => 'Xuxemon no encontrado'], 404);
        }
    }

    // Crear xuxemon
    public function create()
    {
        return view('xuxemons.create');
    }

    // Guardar datos
    public function store(Request $request)
    {
        try {
            $request->validate([
                //                'idUsuario' => 'required|string',
                'nombre' => 'required|string',
                'tipo' => 'required|in:Tierra,Agua,Aire',
                'tamano' => 'required|in:Pequeño,Mediano,Grande',
                'img' => 'required|string',
            ]);

            Xuxemon::create($request->all());

            return response()->json(['message' => 'Xuxemon creado correctamente'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Xuxemon no insertado'], 404);
        }
    }

    public function edit(Xuxemon $xuxemon)
    {
        return view('xuxemons.edit', compact('xuxemon'));
    }

    public function update(Request $request, $id)
    {
        try {

            $datos = $request->validate([
                'nombre' => 'required|string',
                'tipo' => 'required|in:Tierra,Agua,Aire',
                'tamano' => 'required|in:Pequeño,Mediano,Grande',
                'img' => 'required|string',
            ]);

            $xuxemon = Xuxemon::findOrFail($id);
            $xuxemon->update($datos);

            return response()->json(['xuxemon' => $xuxemon, 'message' => 'Xuxemon actualizado correctamente'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Xuxemon no actualizado'], 404);
        }
    }

    public function destroy($id)
    {
        $xuxemon = Xuxemon::findOrFail($id);
        $xuxemon->delete();

        return response()->json(['message' => 'Xuxemon eliminado correctamente'], 200);
    }


    public function activarXuxemon($id)
    {
        // Encontrar el Xuxemon por su ID
        $xuxemon = Xuxemon::findOrFail($id);

        // Verificar si el Xuxemon tiene la enfermedad "Sobredosis de azúcar"
        if ($xuxemon->enfermedad === 'Sobredosis de azúcar') {
            return response()->json(['error' => 'No se puede activar este Xuxemon porque tiene la enfermedad "Sobredosis de azúcar"'], 422);
        }

        // Verificar si hay más de 4 Xuxemons activos
        $activeXuxemonsCount = Xuxemon::where('activo', true)->count();

        if ($xuxemon->activo) {
            // Si el Xuxemon ya está activo, lo desactivamos
            $xuxemon->activo = false;
            $message = 'Xuxemon desactivado con éxito';
        } elseif ($activeXuxemonsCount >= 4) {
            // Si hay 4 o más Xuxemons activos, no podemos activar más
            return response()->json(['error' => 'No se puede activar más Xuxemons, ya hay 4 activos'], 422);
        } else {
            // Si hay menos de 4 Xuxemons activos, activamos el Xuxemon
            $xuxemon->activo = true;
            $message = 'Xuxemon activado con éxito';
        }

        // Guardar los cambios en la base de datos
        $xuxemon->save();

        // Devolver una respuesta
        return response()->json(['message' => $message]);
    }

    // Función para recoger solo los xuxemons que estén enfermos
    public function hospital()
    {
        $xuxemons = Xuxemon::all();
        $xuxemonsEnfermos = [];
    
        foreach ($xuxemons as $xuxemon) {
            // Verificar si alguno de los campos de enfermedad está activo
            if ($xuxemon->bajon_azucar || $xuxemon->sobredosis_azucar || $xuxemon->atracon) {
                // Agregar el Xuxemon al arreglo de los que necesitan tratamiento
                $xuxemonsEnfermos[] = $xuxemon;
            }
        }
    
        if (count($xuxemonsEnfermos) > 0) {
            return response()->json($xuxemonsEnfermos, 200);
        } else {
            return response()->json(['message' => 'No hay Xuxemons enfermos.'], 200);
        }
    }

    // Función para subir el nivel y controlar las enfermedades
    public function darXuxe(Request $request, $idXuxemon, $idChuche)
    {
        // Obtener los ajustes
        $ajustesController = new controladorUsuarios();
        $ajustesResponse = $ajustesController->cogerAjustes();
        if ($ajustesResponse->getStatusCode() === 200) {
            $ajustes = json_decode($ajustesResponse->getContent());
            $amediano = $ajustes[1];
            $agrande = $ajustes[2];
        } else {
            // Manejar el error si no se pueden obtener los ajustes
            return $ajustesResponse;
        }

        $xuxemon = Xuxemon::findOrFail($idXuxemon);
        $chuche = Inventario::findOrFail($idChuche);

        // Verificar la cantidad de la Xuxe
        if ($chuche->cantidad > 0) {
            // Verificar si es una Xuxe o un Objeto
            if ($chuche->tipo === 'Xuxes'){
                // Verificar si el Xuxemon tiene la enfermedad "Atracón"
                if ($xuxemon->atracon == true) {
                    return response()->json(['message' => 'No puedes alimentar un xuxemon con "Atracón".'], 400);
                } else {
                    // Bajar la cantidad de la Xuxe
                    $chuche->cantidad -= 1;
                    $chuche->save();

                    // Si el Xuxemon tiene la enfermedad "Bajón de azúcar", necesitará 2 xuxes para crecer
                    if ($xuxemon->bajon_azucar == true) {
                        $xuxemon->nivel += 1;
                        if ($xuxemon->nivel == $amediano+2) {
                            $xuxemon->tamano = 'Mediano';
                        } elseif ($xuxemon->nivel == $agrande+2) {
                            $xuxemon->tamano = 'Grande';
                        }
                    } else {
                        $xuxemon->nivel += 1;
                        if ($xuxemon->nivel == $amediano) {
                            $xuxemon->tamano = 'Mediano';
                        } elseif ($xuxemon->nivel == $agrande) {
                            $xuxemon->tamano = 'Grande';
                        }
                    }

                    // Actualizar el tamaño del Xuxemon si es necesario
                    

                    // Comprobar si el Xuxemon se ha infectado
                    $numero = rand(1, 100);
                    if ($numero <= 5) {
                        $xuxemon->bajon_azucar = true;
                    } elseif ($numero <= 15) {
                        $xuxemon->sobredosis_azucar = true;
                    } elseif ($numero <= 30) {
                        $xuxemon->atracon = true;
                    }
                    
                    // Guardar la información
                    $xuxemon->save();
                    return response()->json(['message' => 'El nivel del xuxemon se ha actualizado correctamente'], 200);
                }
            } else {
                // Bajar la cantidad de la Xuxe
                $chuche->cantidad -= 1;
                $chuche->save();

                // Comprobar si el objeto tiene efecto sobre el Xuxemon
                if ($chuche->nombre == 'Xocolatina' && $xuxemon->bajon_azucar) {
                    $xuxemon->bajon_azucar = false;
                    if ($xuxemon->nivel == $amediano) {
                        $xuxemon->tamano = 'Mediano';
                    } elseif ($xuxemon->nivel == $agrande) {
                        $xuxemon->tamano = 'Grande';
                    }
                    $xuxemon->save();
                    return response()->json(['message' => 'El xuxemon se ha curado del "Bajón de azúcar".'], 200);
                } 
                elseif ($chuche->nombre == 'Inxulina' && $xuxemon->sobredosis_azucar) {
                    $xuxemon->sobredosis_azucar = false;
                    $xuxemon->save();
                    return response()->json(['message' => 'El xuxemon se ha curado de la "Sobredosis de azúcar".'], 200);
                } 
                elseif ($chuche->nombre == 'Xal de frutas' && $xuxemon->atracon) {
                    $xuxemon->atracon = false;
                    $xuxemon->save();
                    return response()->json(['message' => 'El xuxemon se ha curado del "Atracón".'], 200);
                } else {
                    return response()->json(['message' => 'El objeto no ha tenido ningun efecto '], 200);
                }

                
            }
        } else {
            return response()->json(['message' => 'La cantidad de la Xuxe es insuficiente'], 400);
        }
    }
}
