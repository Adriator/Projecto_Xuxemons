<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Xuxemon extends Model
{
    use HasFactory;

    protected $table = 'xuxemon';

    protected $fillable = [
        'nombre',
        'tipo',
        'tamano', 
        'img',
        'nivel',
        'activo',
        'bajon_azucar',
        'sobredosis_azucar',
        'atracon',
    ];
}