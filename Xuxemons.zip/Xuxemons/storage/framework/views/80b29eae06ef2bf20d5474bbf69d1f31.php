

<?php $__env->startSection('content'); ?>
    <h1>Agregar Xuxemon</h1>

    <form action="<?php echo e(route('xuxemons.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
<!--     <label for="idUsuario">id.Usuario:</label>
         <input type="text" name="idUsuario" step="0.01"> -->

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" required>
            <option value="Agua">Agua</option>
            <option value="Tierra">Tierra</option>
            <option value="Aire">Aire</option>
        </select>

        <label for="img">Imagen:</label>
        <input type="image" name="img" required>
        
        <button type="submit">Guardar Xuxemon</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ilerna\DAW 2\Xuxemons\Fase 1\Xuxemons\resources\views/xuxemons/create.blade.php ENDPATH**/ ?>