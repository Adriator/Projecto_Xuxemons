

<?php $__env->startSection('content'); ?>
    <h1>Editar Usuario</h1>

    <form method="POST" action="<?php echo e(route('usuarios.update', $user->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> 
        
        <label for="name">Nombre:</label>
        <input type="text" name="name" value="<?php echo e($user->name); ?>" required>

        <label for="email">Correo electrónico:</label>
        <input type="email" name="email" value="<?php echo e($user->email); ?>" required>
        
        <button type="submit">Guardar Cambios</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ilerna\DAW 2\Xuxemons\Fase 1\Xuxemons\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>