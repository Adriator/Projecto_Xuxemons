

<?php $__env->startSection('content'); ?>
    <h1>Crear usuario</h1>

    <form method="POST" action="<?php echo e(route('usuarios.store')); ?>">
        <?php echo csrf_field(); ?>

        <label for="name">Nombre:</label>
        <input type="text" name="name" required>

        <label for="email">Correo electrónico:</label>
        <input type="email" name="email" required>

        <label for="password">Contraseña:</label>
        <input type="password" name="password" required>

        <label for="rol">Rol:</label>
        <input type="rol" name="rol" required>

        <button type="submit">Guardar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ilerna\DAW 2\Xuxemons\Fase 1\Xuxemons\resources\views/usuarios/create.blade.php ENDPATH**/ ?>